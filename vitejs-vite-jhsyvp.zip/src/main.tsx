import ReactDOM from 'react-dom/client';
import CivilEngineeringPDFSystem from './Ingeniero Civil Virtual prueba 1';

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<CivilEngineeringPDFSystem />);
}
